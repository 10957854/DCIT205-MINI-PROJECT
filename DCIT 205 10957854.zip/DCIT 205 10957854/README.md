This API provides the following endpoints:
 • GET Endpoint: /api/data - Retrieves data from the server.
 • POST Endpoint: /api/data - Sends data to the server.
GET Endpoint
The GET endpoint retrieves data from the server. To use this endpoint, send a GET request to /api/data with the following parameters:
 • id: The ID of the data you want to retrieve. (Optional)
The response will be a JSON object with the following fields:
 • id: The ID of the data.
 • name: The name of the data.
 • description: The description of the data.

 //EXAMPLE OF REQUEST
 GET /api/data?id=1 HTTP/1.1

 //RESPONSE WILL BE IN THE FORM
 {
  "id": 1,
  "name": "Data 1",
  "description": "This is the description for data 1."
}

POST Endpoint
The POST endpoint sends data to the server. To use this endpoint, send a POST request to /api/data with the following parameters in the request body:
 • name: The name of the data.
 • description: The description of the data.
The response will be a JSON object with the following fields:
 • id: The ID of the data.
 • name: The name of the data.
 • description: The description of the data.

 //EXAMPLE OF POST REQUEST
POST /api/data HTTP/1.1
Content-Type: application/json

{
  "name": "Data 2",
  "description": "This is the description for data 2."
}

//RESPONSE FOR REQUEST
{
  "id": 2,
  "name": "Data 2",
  "description": "This is the description for data 2."
}



You should now be able to consume the GET and POST endpoints described in this README. THANK YOU!!